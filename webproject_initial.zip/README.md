# web_project_1030
The final project for the introductory web design course CPSC1030.

## index.html
The landing page for the website.

## stylesheet.css
The global style all the webpages in our web project will use
